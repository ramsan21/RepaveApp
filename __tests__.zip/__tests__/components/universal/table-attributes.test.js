import tableIcons, {
  options,
} from "../../../component/Universal/table_attributes";

describe("Universal Component - table-attributes", () => {
  test("Testing the length of tableIcons", () => {
    expect(Object.keys(tableIcons)).toHaveLength(18);
  });
  test("Testing the length of options", () => {
    expect(Object.keys(options)).toHaveLength(13);
  });
});
