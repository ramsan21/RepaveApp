import React from "react";
import { render, fireEvent, screen, cleanup } from "@testing-library/react";
// import userEvent from "@testing-library/user-event";
import AppBarComponent from "../../component/AppBarComponent";
import "@testing-library/jest-dom";

beforeAll(() => render(<AppBarComponent />));
afterAll(cleanup);

describe("Testing AppBarComponent", () => {
  test("Cogent Health is in the header", async () => {
    // screen.debug();
    expect(
      screen.getByPlaceholderText("Search for products, brands and more")
    ).toBeInTheDocument();
    // expect(screen.queryByRole("Open Drawer")).toBeInTheDocument();
    // userEvent.click(screen.getByRole("Open Drawer"));
    // screen.debug();
  });
});
