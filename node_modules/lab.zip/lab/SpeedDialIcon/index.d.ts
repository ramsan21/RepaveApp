export { default } from './SpeedDialIcon';
export * from './SpeedDialIcon';
