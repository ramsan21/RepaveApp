export { default } from './TimelineDot';
export * from './TimelineDot';
