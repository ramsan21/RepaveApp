export { default } from './TabPanel';
export * from './TabPanel';
